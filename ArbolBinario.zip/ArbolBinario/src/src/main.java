package src;
import java.util.Scanner;


public class main {
    public static void main(String[] args) {

       // Scanner entrada = new Scanner(System.in);
        Arbol ab1 = new Arbol();
        Nodo nodo = new Nodo(1);

        ab1.insertar(nodo,10);

        nodo.imprimirArbol();
        System.out.println(ab1.vacio(nodo,9));
    }
}